<?php
/*
 Plugin Name: 碎语页面
 Plugin URI:
 Description: 碎语页面
 Version: 1.0.0
 Author: zkl2333
 Author URI: http://zkl2333.com
 License: GPL
 */
###################定义碎语页面#######################
add_action('init', 'my_custom_init');
function my_custom_init() {
	$labels = array('name' => '碎语', 'singular_name' => '碎语', 'add_new' => '发表新碎语', 'add_new_item' => '发表新碎语', 'edit_item' => '编辑碎语', 'new_item' => '新碎语', 'all_items' => '所有碎语', 'view_item' => '查看碎语', 'search_items' => '搜索碎语', 'not_found' => '暂无碎语', 'not_found_in_trash' => '没有已遗弃的碎语', 'parent_item_colon' => '', 'menu_name' => '碎语');
	$args = array('labels' => $labels, 'public' => true, 'publicly_queryable' => true, 'show_ui' => true, 'show_in_menu' => true, 'query_var' => true, 'rewrite' => true, 'can_export' => true, 'capability_type' => 'post', 'has_archive' => false, 'hierarchical' => false, 'menu_position' => null, 'supports' => array('title', 'editor', 'thumbnail', 'author'), );
	register_post_type('word', $args);
}

######################在主循环输出##########################
//要在主循环输出去掉下一行注释
//add_action( 'pre_get_posts', 'add_my_post_types_to_query' );

function add_my_post_types_to_query($query) {
	if (is_home() && $query -> is_main_query())
		$query -> set('post_type', array('post', 'word'));
	return $query;
}

####################碎语css模板#################################
function loop_word() {

	query_posts("post_type=word&post_status=publish");
	if (have_posts()) {

		echo ' <style type="text/css">
	.animated {
	-webkit-animation-duration: 1s;
	   -moz-animation-duration: 1s;
	    -ms-animation-duration: 1s;
	     -o-animation-duration: 1s;
	        animation-duration: 1s;
	-webkit-animation-fill-mode: both;
	   -moz-animation-fill-mode: both;
	    -ms-animation-fill-mode: both;
	     -o-animation-fill-mode: both;
	        animation-fill-mode: both;
}

.animated.hinge {
	-webkit-animation-duration: 2s;
	   -moz-animation-duration: 2s;
	    -ms-animation-duration: 2s;
	     -o-animation-duration: 2s;
	        animation-duration: 2s;
}

@-webkit-keyframes bounceIn {
	0% {
		opacity: 0;
		-webkit-transform: scale(.3);
	}

	50% {
		opacity: 1;
		-webkit-transform: scale(1.1);
	}

	70% {
		-webkit-transform: scale(.9);
	}

	100% {
		-webkit-transform: scale(1);
	}
}

@-moz-keyframes bounceIn {
	0% {
		opacity: 0;
		-moz-transform: scale(.3);
	}

	50% {
		opacity: 1;
		-moz-transform: scale(1.1);
	}

	70% {
		-moz-transform: scale(.9);
	}

	100% {
		-moz-transform: scale(1);
	}
}

@-ms-keyframes bounceIn {
	0% {
		opacity: 0;
		-ms-transform: scale(.3);
	}

	50% {
		opacity: 1;
		-ms-transform: scale(1.1);
	}

	70% {
		-ms-transform: scale(.9);
	}

	100% {
		-ms-transform: scale(1);
	}
}

@-o-keyframes bounceIn {
	0% {
		opacity: 0;
		-o-transform: scale(.3);
	}

	50% {
		opacity: 1;
		-o-transform: scale(1.1);
	}

	70% {
		-o-transform: scale(.9);
	}

	100% {
		-o-transform: scale(1);
	}
}

@keyframes bounceIn {
	0% {
		opacity: 0;
		transform: scale(.3);
	}

	50% {
		opacity: 1;
		transform: scale(1.1);
	}

	70% {
		transform: scale(.9);
	}

	100% {
		transform: scale(1);
	}
}

.bounceIn {
	-webkit-animation-name: bounceIn;
	-moz-animation-name: bounceIn;
	-ms-animation-name: bounceIn;
	-o-animation-name: bounceIn;
	animation-name: bounceIn;
}



.class_ p:hover {
	color: #ffffff;
	border: 1px solid #44cef6;
	background: #44cef6 none repeat scroll 0 0;
	transition: all 0.2s ease-in 0s;
	
}

.class_ h1 time{float:none !important;}

.class_ p{
	border: 1px solid #F5F5DC;
	border-radius: 5px;
	box-shadow: 2px 2px 6px gray;
	padding: 15px 15px;
	margin-bottom: 20px
}

.class_ {padding-top: 0px !important;}

.word {
	border: 1px solid #F5F5DC;
	border-radius: 5px;
	box-shadow: 2px 2px 6px gray;
	padding: 15px 15px;
	margin-bottom: 20px
}

.word:hover {
	color: #ffffff;
	border: 1px solid #44cef6;
	background: #44cef6 none repeat scroll 0 0;
	transition: all 0.2s ease-in 0s;
	
}

.word+.word {
    margin-top: 20px;
}

.word-cont {
	font-size: 15px;
	word-break: break-all;
	letter-spacing: 1px
}

.word-cont p {
	margin: 0 0 10px 0;
}

.word-time {
	text-align:right;
} </style> ';
		while (have_posts()) {
			echo the_post();
			echo '<div class="word animated bounceIn">
	      <div class="word-cont">';
			echo the_content() . '</div>';
			echo '<div class="word-time">';
			echo the_time('Y/m/d H:i');
			echo '</div></div>';
		}
	} else {
		echo '<p class="_404">没发现什么...</p>';
	}
	wp_reset_query();
}

################短代码###################
add_shortcode('word', 'loop_word');
#########################################
function add_stylesheet_to_head() {
	echo '<style type="text/css">
.class_ p:hover {
color: #ffffff;
border: 1px solid #44cef6;
background: #44cef6 none repeat scroll 0 0;
transition: all 0.2s ease-in 0s;

}

.class_ h1 time{float:none !important;}

.class_ p{
border: 1px solid #F5F5DC;
border-radius: 5px;
box-shadow: 2px 2px 6px gray;
padding: 15px 15px;
margin-bottom: 20px
}

.class_ {padding-top: 0px !important;}</style>';
}

add_action('wp_head', 'add_stylesheet_to_head');
